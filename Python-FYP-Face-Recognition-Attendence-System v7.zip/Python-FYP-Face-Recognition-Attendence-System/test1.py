import tkinter as tk

class TermsAndConditionsApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Show/Hide Terms and Conditions")

        self.terms_text = (
            "1. This is the first term.\n"
            "2. This is the second term.\n"
            "3. This is the third term.\n"
            "4. ... and so on."
        )

        self.terms_popup = tk.Toplevel(root)
        self.terms_popup.title("Terms and Conditions")
        self.terms_popup.withdraw()  # Hide the popup initially

        self.terms_text_widget = tk.Text(self.terms_popup, wrap=tk.WORD, height=10, width=40, font=("verdana",13,"bold"),fg="black",highlightthickness=-1)
        self.terms_text_widget.pack(padx=10, pady=10)
        self.terms_text_widget.insert(tk.END, self.terms_text)

        self.checkbox_var = tk.IntVar()
        self.checkbox = tk.Checkbutton(self.terms_popup, text="I agree to the terms", variable=self.checkbox_var)
        self.checkbox.pack()

        # Bind the X button (closing) to the hide_terms method
        self.terms_popup.protocol("WM_DELETE_WINDOW", self.hide_terms)

        self.show_button = tk.Button(root, text="Show Terms", command=self.show_terms)
        self.show_button.pack(pady=5)

    def show_terms(self):
        self.terms_popup.deiconify()  # Show the popup
        self.show_button.config(state=tk.DISABLED)

    def hide_terms(self):
        self.terms_popup.withdraw()  # Hide the popup
        self.show_button.config(state=tk.NORMAL)

if __name__ == "__main__":
    root = tk.Tk()
    app = TermsAndConditionsApp(root)
    root.mainloop()
